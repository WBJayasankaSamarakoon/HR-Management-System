<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ueshrdb');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch all data from the Event table
$sql = "SELECT * FROM Event";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Events</title>
    <!-- Optional: Add Bootstrap for styling -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2 class="mt-5">Events List</h2>
        <table class="table table-bordered mt-3">
            <thead>

                <th>ID</th>
                <th>Title</th>

                <th>Date</th>



            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['Id'] . "</td>";
                        echo "<td>" . $row['Title'] . "</td>";

                        echo "<td>" . $row['Date'] . "</td>";



                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No events found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>

<?php
// Close the database connection
$conn->close();
?>