<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ueshrdb";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the next index number
    $result = $conn->query("SELECT MAX(`Index`) AS maxIndex FROM ueshrattendancedaily");
    $row = $result->fetch_assoc();
    $nextIndex = $row['maxIndex'] + 1;

    // Retrieve and escape form data
    $personID = $conn->real_escape_string($_POST['personID']);
    $name = $conn->real_escape_string($_POST['name']);
    $department = $conn->real_escape_string($_POST['department']);
    $position = $conn->real_escape_string($_POST['position']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $date = $conn->real_escape_string($_POST['date']);
    $week = $conn->real_escape_string($_POST['week']);
    $timetable = $conn->real_escape_string($_POST['timetable']);
    $checkin = $conn->real_escape_string($_POST['checkin']);
    $checkout = $conn->real_escape_string($_POST['checkout']);
    $work = $conn->real_escape_string($_POST['work']);
    $ot = $conn->real_escape_string($_POST['ot']);
    $attended = $conn->real_escape_string($_POST['attended']);
    $late = $conn->real_escape_string($_POST['late']);
    $early = $conn->real_escape_string($_POST['early']);
    $absent = $conn->real_escape_string($_POST['absent']);
    $leave = $conn->real_escape_string($_POST['leave']);
    $status = $conn->real_escape_string($_POST['status']);
    $records = $conn->real_escape_string($_POST['records']);

    // Insert data into the database
    $sql = "INSERT INTO ueshrattendancedaily (`Index`, PersonID, Name, Department, Position, Gender, Date, Week, Timetable, CheckIn, CheckOut, Work, OT, Attended, Late, Early, Absent, `Leave`, `Status`, Records)
            VALUES ('$nextIndex', '$personID', '$name', '$department', '$position', '$gender', '$date', '$week', '$timetable', '$checkin', '$checkout', '$work', '$ot', '$attended', '$late', '$early', '$absent', '$leave', '$status', '$records')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Employee added successfully!'); window.location.href='php_sheet/view_attendance.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .popup {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            visibility: hidden;
        }

        .popup.active {
            visibility: visible;
        }

        .popup-content {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            width: 500px;
            max-width: 90%;
        }

        .popup-content h2 {
            margin-top: 0;
        }

        .popup-content .form-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .popup-content label {
            display: block;
            font-size: 12px;
        }

        .popup-content input[type="text"],
        .popup-content input[type="date"],
        .popup-content select {
            width: 100%;
            padding: 5px;
            margin-top: 3px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 12px;
        }

        .popup-content button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
            font-size: 14px;
        }

        .popup-content button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <button onclick="showPopup()">Add New Employee</button>

    <div class="popup" id="popup">
        <div class="popup-content">
            <h2>Add Employee</h2>
            <form action="php_sheet/add_employee.php" method="post">
                <div class="form-row">
                    <div>
                        <label for="personID">Person ID:</label>
                        <input type="text" id="personID" name="personID" required>
                    </div>
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="department">Department:</label>
                        <input type="text" id="department" name="department" required>
                    </div>
                    <div>
                        <label for="position">Position:</label>
                        <input type="text" id="position" name="position" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="gender">Gender:</label>
                        <select id="gender" name="gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div>
                        <label for="date">Date:</label>
                        <input type="date" id="date" name="date" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="week">Week:</label>
                        <input type="text" id="week" name="week" required>
                    </div>
                    <div>
                        <label for="timetable">Timetable:</label>
                        <input type="text" id="timetable" name="timetable" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="checkin">Check-in:</label>
                        <input type="text" id="checkin" name="checkin" required>
                    </div>
                    <div>
                        <label for="checkout">Check-out:</label>
                        <input type="text" id="checkout" name="checkout" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="work">Work:</label>
                        <input type="text" id="work" name="work" required>
                    </div>
                    <div>
                        <label for="ot">OT:</label>
                        <input type="text" id="ot" name="ot" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="attended">Attended:</label>
                        <input type="text" id="attended" name="attended" required>
                    </div>
                    <div>
                        <label for="late">Late:</label>
                        <input type="text" id="late" name="late" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="early">Early:</label>
                        <input type="text" id="early" name="early" required>
                    </div>
                    <div>
                        <label for="absent">Absent:</label>
                        <input type="text" id="absent" name="absent" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="leave">Leave:</label>
                        <input type="text" id="leave" name="leave" required>
                    </div>
                    <div>
                        <label for="status">Status:</label>
                        <input type="text" id="status" name="status" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="records">Records:</label>
                        <input type="text" id="records" name="records" required>
                    </div>
                </div>
                <button type="submit">Save Employee</button>
            </form>
        </div>
    </div>

    <script>
        function showPopup() {
            document.getElementById('popup').classList.add('active');
        }
    </script>
</body>

</html>