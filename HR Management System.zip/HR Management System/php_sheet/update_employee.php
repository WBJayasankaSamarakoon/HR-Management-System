<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the employee ID from the query string
$employeeId = $conn->real_escape_string($_GET['id']);

// Retrieve the updated data from the POST request
$personID = $conn->real_escape_string($_POST['personID']);
$name = $conn->real_escape_string($_POST['name']);
$department = $conn->real_escape_string($_POST['department']);
$position = $conn->real_escape_string($_POST['position']);
$gender = $conn->real_escape_string($_POST['gender']);
$date = $conn->real_escape_string($_POST['date']);
$week = $conn->real_escape_string($_POST['week']);
$timetable = $conn->real_escape_string($_POST['timetable']);
$checkin = $conn->real_escape_string($_POST['checkin']);
$checkout = $conn->real_escape_string($_POST['checkout']);
$work = $conn->real_escape_string($_POST['work']);
$ot = $conn->real_escape_string($_POST['ot']);
$attended = $conn->real_escape_string($_POST['attended']);
$late = $conn->real_escape_string($_POST['late']);
$early = $conn->real_escape_string($_POST['early']);
$absent = $conn->real_escape_string($_POST['absent']);
$leave = $conn->real_escape_string($_POST['leave']);
$status = $conn->real_escape_string($_POST['status']);
$records = $conn->real_escape_string($_POST['records']);

// Update query with backticks for reserved keywords and proper escaping
$sql = "UPDATE ueshrattendancedaily SET 
    PersonID='$personID',
    Name='$name',
    Department='$department',
    Position='$position',
    Gender='$gender',
    Date='$date',
    Week='$week',
    Timetable='$timetable',
    CheckIn='$checkin',
    CheckOut='$checkout',
    Work='$work',
    OT='$ot',
    Attended='$attended',
    Late='$late',
    Early='$early',
    Absent='$absent',
    `Leave`='$leave',
    Status='$status',
    Records='$records'
    WHERE `Index`='$employeeId'";

if ($conn->query($sql) === TRUE) {
    // Redirect back to the attendance sheet
    header("Location: php_sheet/view_attendance.php");
    exit();
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>