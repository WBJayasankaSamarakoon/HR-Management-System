<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['excelFile']) && $_FILES['excelFile']['error'] == 0) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $uploadFile = $uploadDir . basename($_FILES['excelFile']['name']);

        if (move_uploaded_file($_FILES['excelFile']['tmp_name'], $uploadFile)) {
            // Load the spreadsheet
            $spreadsheet = IOFactory::load($uploadFile);
            if (!$spreadsheet) {
                die("Failed to load the spreadsheet.");
            }

            // Get the active sheet
            $sheet = $spreadsheet->getActiveSheet();
            $data = $sheet->toArray();

            // Database connection details
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "ueshrdb";

            // Create a connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $importSuccess = true;

            // Iterate over the data and insert into the database
            foreach ($data as $index => $row) {
                if ($index === 0) {
                    continue;  // Skip header row
                }

                // Adjust column indices as needed
                $index = $conn->real_escape_string($row[0]);
                $personID = $conn->real_escape_string($row[1]);
                $name = $conn->real_escape_string($row[2]);
                $department = $conn->real_escape_string($row[3]);
                $position = $conn->real_escape_string($row[4]);
                $gender = $conn->real_escape_string($row[5]);
                $date = $conn->real_escape_string($row[6]);
                $week = $conn->real_escape_string($row[7]);
                $timetable = $conn->real_escape_string($row[8]);
                $checkin = $conn->real_escape_string($row[9]);
                $checkout = $conn->real_escape_string($row[10]);
                $work = $conn->real_escape_string($row[11]);
                $ot = $conn->real_escape_string($row[12]);
                $attended = $conn->real_escape_string($row[13]);
                $late = $conn->real_escape_string($row[14]);
                $early = $conn->real_escape_string($row[15]);
                $absent = $conn->real_escape_string($row[16]);
                $leave = $conn->real_escape_string($row[17]);
                $status = $conn->real_escape_string($row[18]);
                $records = $conn->real_escape_string($row[19]);

                $sql = "INSERT INTO ueshrattendancedaily (`Index`, PersonID, Name, Department, Position, Gender, Date, Week, Timetable, CheckIn, CheckOut, Work, OT, Attended, Late, Early, Absent, `Leave`, `Status`, Records)
                        VALUES ('$index', '$personID', '$name', '$department', '$position', '$gender', '$date', '$week', '$timetable', '$checkin', '$checkout', '$work', '$ot', '$attended', '$late', '$early', '$absent', '$leave', '$status', '$records')";

                if ($conn->query($sql) === FALSE) {
                    $importSuccess = false;
                    break; // Stop on first error
                }
            }

            $conn->close();

            if ($importSuccess) {
                echo "<p>Uploading file to: $uploadFile</p>";
                echo "<p>File is valid, and was successfully uploaded.</p>";
                echo "<p>Data imported successfully!</p>";
            } else {
                echo "<p>Data import failed!</p>";
            }
        } else {
            echo "<p>Possible file upload attack!</p>";
        }
    } else {
        echo "<p>No file uploaded or upload error. Error Code: " . $_FILES['excelFile']['error'] . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Attendance Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }

        h1 {
            text-align: center;
        }

        form {
            background-color: #f9f9f9;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            max-width: 400px;
            margin: auto;
        }

        input[type="file"] {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <h1>Upload Attendance Report</h1>
    <form action="php_sheet/index.php" method="post" enctype="multipart/form-data">
        <input type="file" name="excelFile" accept=".xlsx, .xls">
        <button type="submit">Upload</button>
    </form>
</body>

</html>