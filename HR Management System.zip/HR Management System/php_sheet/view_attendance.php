<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Report View</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 12px;
        }

        th,
        td {
            padding: 4px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .action-buttons button {
            padding: 10px 15px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .action-buttons button:hover {
            background-color: #0056b3;
        }

        .edit-btn {
            background-color: #28a745;
            margin: 5px;
        }

        .edit-btn:hover {
            background-color: #218838;
        }

        .delete-btn {
            background-color: #dc3545;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .popup,
        .edit-modal {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            visibility: hidden;
        }

        .popup.active,
        .edit-modal.active {
            visibility: visible;
        }

        .popup-content {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            width: 500px;
            max-width: 90%;
            box-sizing: border-box;
        }

        .edit-modal-content {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            width: 500px;
            /* Same width for consistency */
            max-width: 90%;
            max-height: 90%;
            /* Adjust this value as needed */
            overflow-y: auto;
            /* Adds a scrollbar if content overflows */
            box-sizing: border-box;
        }

        .popup-content h2,
        .edit-modal-content h2 {
            margin-top: 0;
        }

        .popup-content .form-row,
        .edit-modal-content .form-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .popup-content label,
        .edit-modal-content label {
            display: block;
            font-size: 12px;
        }

        .popup-content input[type="text"],
        .popup-content input[type="date"],
        .popup-content select,
        .edit-modal-content input[type="text"],
        .edit-modal-content input[type="date"],
        .edit-modal-content select {
            width: 100%;
            padding: 5px;
            margin-top: 3px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 12px;
        }

        .popup-content button,
        .edit-modal-content button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
            font-size: 14px;
        }

        .popup-content button:hover,
        .edit-modal-content button:hover {
            background-color: #0056b3;
        }


        .event-day {
            background-color: #ffdddd;
        }
    </style>
</head>

<body>
    <h1>Attendance Report</h1>

    <div class="action-buttons">
        <button onclick="showPopup()">Add Employee</button>
    </div>

    <!-- Popup for Adding Employee -->
    <div class="popup" id="popup">
        <div class="popup-content">
            <h2>Add Employee</h2>
            <form action="php_sheet/add_employee.php" method="post">
                <div class="form-row">
                    <div>
                        <label for="personID">Person ID:</label>
                        <input type="text" id="personID" name="personID" required>
                    </div>
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="department">Department:</label>
                        <input type="text" id="department" name="department" required>
                    </div>
                    <div>
                        <label for="position">Position:</label>
                        <input type="text" id="position" name="position" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="gender">Gender:</label>
                        <select id="gender" name="gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div>
                        <label for="date">Date:</label>
                        <input type="date" id="date" name="date" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="week">Week:</label>
                        <input type="text" id="week" name="week" required>
                    </div>
                    <div>
                        <label for="timetable">Timetable:</label>
                        <input type="text" id="timetable" name="timetable" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="checkin">Check-in:</label>
                        <input type="text" id="checkin" name="checkin" required>
                    </div>
                    <div>
                        <label for="checkout">Check-out:</label>
                        <input type="text" id="checkout" name="checkout" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="work">Work:</label>
                        <input type="text" id="work" name="work" required>
                    </div>
                    <div>
                        <label for="ot">OT:</label>
                        <input type="text" id="ot" name="ot" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="attended">Attended:</label>
                        <input type="text" id="attended" name="attended" required>
                    </div>
                    <div>
                        <label for="late">Late:</label>
                        <input type="text" id="late" name="late" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="early">Early:</label>
                        <input type="text" id="early" name="early" required>
                    </div>
                    <div>
                        <label for="absent">Absent:</label>
                        <input type="text" id="absent" name="absent" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="leave">Leave:</label>
                        <input type="text" id="leave" name="leave" required>
                    </div>
                    <div>
                        <label for="status">Status:</label>
                        <input type="text" id="status" name="status" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="records">Records:</label>
                        <input type="text" id="records" name="records" required>
                    </div>
                </div>
                <button type="submit">Save Employee</button>
            </form>
        </div>
    </div>

    <!-- Modal for Editing Employee -->
    <div class="edit-modal" id="editModal">
        <div class="edit-modal-content">
            <h2>Edit Employee</h2>
            <form id="editForm" method="post">
                <!-- The form fields will be populated with JavaScript -->
                <div class="form-row">
                    <div>
                        <label for="editPersonID">Person ID:</label>
                        <input type="text" id="editPersonID" name="personID" required>
                    </div>
                    <div>
                        <label for="editName">Name:</label>
                        <input type="text" id="editName" name="name" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editDepartment">Department:</label>
                        <input type="text" id="editDepartment" name="department" required>
                    </div>
                    <div>
                        <label for="editPosition">Position:</label>
                        <input type="text" id="editPosition" name="position" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editGender">Gender:</label>
                        <select id="editGender" name="gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div>
                        <label for="editDate">Date:</label>
                        <input type="date" id="editDate" name="date" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editWeek">Week:</label>
                        <input type="text" id="editWeek" name="week" required>
                    </div>
                    <div>
                        <label for="editTimetable">Timetable:</label>
                        <input type="text" id="editTimetable" name="timetable" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editCheckin">Check-in:</label>
                        <input type="text" id="editCheckin" name="checkin" required>
                    </div>
                    <div>
                        <label for="editCheckout">Check-out:</label>
                        <input type="text" id="editCheckout" name="checkout" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editWork">Work:</label>
                        <input type="text" id="editWork" name="work" required>
                    </div>
                    <div>
                        <label for="editOt">OT:</label>
                        <input type="text" id="editOt" name="ot" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editAttended">Attended:</label>
                        <input type="text" id="editAttended" name="attended" required>
                    </div>
                    <div>
                        <label for="editLate">Late:</label>
                        <input type="text" id="editLate" name="late" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editEarly">Early:</label>
                        <input type="text" id="editEarly" name="early" required>
                    </div>
                    <div>
                        <label for="editAbsent">Absent:</label>
                        <input type="text" id="editAbsent" name="absent" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editLeave">Leave:</label>
                        <input type="text" id="editLeave" name="leave" required>
                    </div>
                    <div>
                        <label for="editStatus">Status:</label>
                        <input type="text" id="editStatus" name="status" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="editRecords">Records:</label>
                        <input type="text" id="editRecords" name="records" required>
                    </div>
                </div>
                <button type="submit">Update Employee</button>
                <button type="button" onclick="hideEditModal()">Cancel</button>
            </form>
        </div>
    </div>

    <?php
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ueshrdb";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve attendance records
    $attendanceResult = $conn->query("SELECT * FROM ueshrattendancedaily");

    // Retrieve event dates
    $eventResult = $conn->query("SELECT Date FROM event");

    // Store event dates in an array for easy lookup
    $eventDates = [];
    while ($eventRow = $eventResult->fetch_assoc()) {
        $eventDates[] = $eventRow['Date'];
    }

    // Fetch data from the database
    $sql = "SELECT * FROM ueshrattendancedaily";
    $attendanceResult = $conn->query($sql);

    if ($attendanceResult->num_rows > 0) {
        echo "<table>
            <tr>
                <th>Index</th>
                <th>Person ID</th>
                <th>Name</th>
                <th>Department</th>
                <th>Position</th>
                <th>Gender</th>
                <th>Date</th>
                <th>Week</th>
                <th>Timetable</th>
                <th>Check-in</th>
                <th>Check-out</th>
                <th>Work</th>
                <th>OT</th>
                <th>Attended</th>
                <th>Late</th>
                <th>Early</th>
                <th>Absent</th>
                <th>Leave</th>
                <th>Status</th>
                <th>Records</th>
                <th>Actions</th>
            </tr>";

        // Output data of each row
        while ($row = $attendanceResult->fetch_assoc()) {
            // Check if the date is in the event dates
            $isEventDay = in_array($row["Date"], $eventDates) ? 'event-day' : '';

            echo "<tr class='$isEventDay'>
                <td>" . $row["Index"] . "</td>
                <td>" . $row["PersonID"] . "</td>
                <td>" . $row["Name"] . "</td>
                <td>" . $row["Department"] . "</td>
                <td>" . $row["Position"] . "</td>
                <td>" . $row["Gender"] . "</td>
                <td>" . $row["Date"] . "</td>
                <td>" . $row["Week"] . "</td>
                <td>" . $row["Timetable"] . "</td>
                <td>" . $row["CheckIn"] . "</td>
                <td>" . $row["CheckOut"] . "</td>
                <td>" . $row["Work"] . "</td>
                <td>" . $row["OT"] . "</td>
                <td>" . $row["Attended"] . "</td>
                <td>" . $row["Late"] . "</td>
                <td>" . $row["Early"] . "</td>
                <td>" . $row["Absent"] . "</td>
                <td>" . $row["Leave"] . "</td>
                <td>" . $row["Status"] . "</td>
                <td>" . $row["Records"] . "</td>
                <td>
                    <button onclick='editEmployee(" . $row["Index"] . ", \"" . $row["PersonID"] . "\", \"" . $row["Name"] . "\", \"" . $row["Department"] . "\", \"" . $row["Position"] . "\", \"" . $row["Gender"] . "\", \"" . $row["Date"] . "\", \"" . $row["Week"] . "\", \"" . $row["Timetable"] . "\", \"" . $row["CheckIn"] . "\", \"" . $row["CheckOut"] . "\", \"" . $row["Work"] . "\", \"" . $row["OT"] . "\", \"" . $row["Attended"] . "\", \"" . $row["Late"] . "\", \"" . $row["Early"] . "\", \"" . $row["Absent"] . "\", \"" . $row["Leave"] . "\", \"" . $row["Status"] . "\", \"" . $row["Records"] . "\")' class='edit-btn'>Edit</button>
                    <form action='delete_employee.php' method='post' style='display:inline;'>
                        <input type='hidden' name='id' value='" . $row["Index"] . "'>
                        <button type='submit' class='delete-btn'>Delete</button>
                    </form>
                </td>
            </tr>";
        }

        echo "</table>";
    } else {
        echo "No records found.";
    }

    $conn->close();
    ?>


    <script>
        function showPopup() {
            document.getElementById('popup').classList.add('active');
        }

        function hidePopup() {
            document.getElementById('popup').classList.remove('active');
        }

        function showEditModal() {
            document.getElementById('editModal').classList.add('active');
        }

        function hideEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function editEmployee(id, personID, name, department, position, gender, date, week, timetable, checkin, checkout, work, ot, attended, late, early, absent, leave, status, records) {
            document.getElementById('editPersonID').value = personID;
            document.getElementById('editName').value = name;
            document.getElementById('editDepartment').value = department;
            document.getElementById('editPosition').value = position;
            document.getElementById('editGender').value = gender;
            document.getElementById('editDate').value = date;
            document.getElementById('editWeek').value = week;
            document.getElementById('editTimetable').value = timetable;
            document.getElementById('editCheckin').value = checkin;
            document.getElementById('editCheckout').value = checkout;
            document.getElementById('editWork').value = work;
            document.getElementById('editOt').value = ot;
            document.getElementById('editAttended').value = attended;
            document.getElementById('editLate').value = late;
            document.getElementById('editEarly').value = early;
            document.getElementById('editAbsent').value = absent;
            document.getElementById('editLeave').value = leave;
            document.getElementById('editStatus').value = status;
            document.getElementById('editRecords').value = records;
            document.getElementById('editForm').action = 'update_employee.php?id=' + id;
            showEditModal();
        }

        // Close popup when clicking outside of it
        window.onclick = function (event) {
            if (event.target == document.getElementById('popup')) {
                hidePopup();
            }
            if (event.target == document.getElementById('editModal')) {
                hideEditModal();
            }
        }


        // Close popup when clicking outside of it
        window.onclick = function (event) {
            if (event.target == document.getElementById('popup')) {
                hidePopup();
            }
        }

    </script>
</body>

</html>