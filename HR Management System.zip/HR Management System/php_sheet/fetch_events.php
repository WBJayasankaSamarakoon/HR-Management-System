<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";  // Correct database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch events from the 'event' table
$events = mysqli_query($conn, "SELECT * FROM event");

$eventArray = [];

// Add events to the event array
while ($row = mysqli_fetch_assoc($events)) {
    // Check if the event is a holiday (assuming there's a field indicating this)
    if ($row['title'] == 'Holiday') {
        $eventArray[] = [
            'title' => 'Holiday',
            'start' => $row['date'],
            'color' => 'red'  // Highlight holidays with a red color
        ];
    } else {
        $eventArray[] = [
            'title' => $row['title'],
            'start' => $row['date'],
            'description' => $row['description']
        ];
    }
}

// Output the events as JSON
echo json_encode($eventArray);
?>