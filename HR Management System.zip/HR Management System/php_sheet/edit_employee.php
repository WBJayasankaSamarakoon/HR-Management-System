<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ueshrdb";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve and escape form data
    $id = $conn->real_escape_string($_POST['id']);
    $personID = $conn->real_escape_string($_POST['personID']);
    $name = $conn->real_escape_string($_POST['name']);
    $department = $conn->real_escape_string($_POST['department']);
    $position = $conn->real_escape_string($_POST['position']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $date = $conn->real_escape_string($_POST['date']);
    $week = $conn->real_escape_string($_POST['week']);
    $timetable = $conn->real_escape_string($_POST['timetable']);
    $checkin = $conn->real_escape_string($_POST['checkin']);
    $checkout = $conn->real_escape_string($_POST['checkout']);
    $work = $conn->real_escape_string($_POST['work']);
    $ot = $conn->real_escape_string($_POST['ot']);
    $attended = $conn->real_escape_string($_POST['attended']);
    $late = $conn->real_escape_string($_POST['late']);
    $early = $conn->real_escape_string($_POST['early']);
    $absent = $conn->real_escape_string($_POST['absent']);
    $leave = $conn->real_escape_string($_POST['leave']);
    $status = $conn->real_escape_string($_POST['status']);
    $records = $conn->real_escape_string($_POST['records']);

    // Update data in the database
    $sql = "UPDATE ueshrattendancedaily
            SET PersonID='$personID', Name='$name', Department='$department', Position='$position', Gender='$gender', Date='$date', Week='$week', Timetable='$timetable', CheckIn='$checkin', CheckOut='$checkout', Work='$work', OT='$ot', Attended='$attended', Late='$late', Early='$early', Absent='$absent', `Leave`='$leave', `Status`='$status', Records='$records'
            WHERE `Index`='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Employee updated successfully!'); window.location.href='php_sheet/view_attendence.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}

// Get employee ID from query string
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the employee record from the database
$sql = "SELECT * FROM ueshrattendancedaily WHERE `Index`='$id'";
$result = $conn->query($sql);
$employee = $result->fetch_assoc();
$conn->close();

if (!$employee) {
    die("Employee not found.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .popup {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            visibility: hidden;
        }

        .popup.active {
            visibility: visible;
        }

        .popup-content {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            width: 500px;
            max-width: 90%;
        }

        .popup-content h2 {
            margin-top: 0;
        }

        .popup-content .form-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .popup-content label {
            display: block;
            font-size: 12px;
        }

        .popup-content input[type="text"],
        .popup-content input[type="date"],
        .popup-content select {
            width: 100%;
            padding: 5px;
            margin-top: 3px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 12px;
        }

        .popup-content button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
            font-size: 14px;
        }

        .popup-content button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <button onclick="showPopup()">Edit Employee</button>

    <div class="popup" id="popup">
        <div class="popup-content">
            <h2>Edit Employee</h2>
            <form action="php_sheet/edit_employee.php" method="post">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($employee['Index']); ?>">
                <div class="form-row">
                    <div>
                        <label for="personID">Person ID:</label>
                        <input type="text" id="personID" name="personID"
                            value="<?php echo htmlspecialchars($employee['PersonID']); ?>" required>
                    </div>
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name"
                            value="<?php echo htmlspecialchars($employee['Name']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="department">Department:</label>
                        <input type="text" id="department" name="department"
                            value="<?php echo htmlspecialchars($employee['Department']); ?>" required>
                    </div>
                    <div>
                        <label for="position">Position:</label>
                        <input type="text" id="position" name="position"
                            value="<?php echo htmlspecialchars($employee['Position']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="gender">Gender:</label>
                        <select id="gender" name="gender" required>
                            <option value="Male" <?php echo $employee['Gender'] == 'Male' ? 'selected' : ''; ?>>Male
                            </option>
                            <option value="Female" <?php echo $employee['Gender'] == 'Female' ? 'selected' : ''; ?>>Female
                            </option>
                        </select>
                    </div>
                    <div>
                        <label for="date">Date:</label>
                        <input type="date" id="date" name="date"
                            value="<?php echo htmlspecialchars($employee['Date']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="week">Week:</label>
                        <input type="text" id="week" name="week"
                            value="<?php echo htmlspecialchars($employee['Week']); ?>" required>
                    </div>
                    <div>
                        <label for="timetable">Timetable:</label>
                        <input type="text" id="timetable" name="timetable"
                            value="<?php echo htmlspecialchars($employee['Timetable']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="checkin">Check-in:</label>
                        <input type="text" id="checkin" name="checkin"
                            value="<?php echo htmlspecialchars($employee['CheckIn']); ?>" required>
                    </div>
                    <div>
                        <label for="checkout">Check-out:</label>
                        <input type="text" id="checkout" name="checkout"
                            value="<?php echo htmlspecialchars($employee['CheckOut']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="work">Work:</label>
                        <input type="text" id="work" name="work"
                            value="<?php echo htmlspecialchars($employee['Work']); ?>" required>
                    </div>
                    <div>
                        <label for="ot">OT:</label>
                        <input type="text" id="ot" name="ot" value="<?php echo htmlspecialchars($employee['OT']); ?>"
                            required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="attended">Attended:</label>
                        <input type="text" id="attended" name="attended"
                            value="<?php echo htmlspecialchars($employee['Attended']); ?>" required>
                    </div>
                    <div>
                        <label for="late">Late:</label>
                        <input type="text" id="late" name="late"
                            value="<?php echo htmlspecialchars($employee['Late']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="early">Early:</label>
                        <input type="text" id="early" name="early"
                            value="<?php echo htmlspecialchars($employee['Early']); ?>" required>
                    </div>
                    <div>
                        <label for="absent">Absent:</label>
                        <input type="text" id="absent" name="absent"
                            value="<?php echo htmlspecialchars($employee['Absent']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="leave">Leave:</label>
                        <input type="text" id="leave" name="leave"
                            value="<?php echo htmlspecialchars($employee['Leave']); ?>" required>
                    </div>
                    <div>
                        <label for="status">Status:</label>
                        <input type="text" id="status" name="status"
                            value="<?php echo htmlspecialchars($employee['Status']); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="records">Records:</label>
                        <input type="text" id="records" name="records"
                            value="<?php echo htmlspecialchars($employee['Records']); ?>" required>
                    </div>
                </div>
                <button type="submit">Save Changes</button>
            </form>
        </div>
    </div>

    <script>
        function showPopup() {
            document.getElementById('popup').classList.add('active');
        }
        document.addEventListener('DOMContentLoaded', showPopup);
    </script>
</body>

</html>