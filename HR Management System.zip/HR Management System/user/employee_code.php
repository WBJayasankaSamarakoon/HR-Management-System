<?php
session_start();
include('db.php');

if (isset($_POST['register_employee'])) {
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirmpassword = mysqli_real_escape_string($conn, $_POST['confirmpassword']);
    $position = mysqli_real_escape_string($conn, $_POST['position']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);

    // Check if passwords match
    if ($password === $confirmpassword) {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert employee into the database
        $query = "INSERT INTO employees (fullname, email, phone, password, position, department) 
                  VALUES ('$fullname', '$email', '$phone', '$hashed_password', '$position', '$department')";
        $query_run = mysqli_query($conn, $query);

        if ($query_run) {
            $_SESSION['success'] = "Employee Added Successfully";
            header('Location: employee_management.php');
        } else {
            $_SESSION['status'] = "Employee Registration Failed";
            header('Location: employee_management.php');
        }
    } else {
        $_SESSION['status'] = "Passwords Do Not Match";
        header('Location: employee_management.php');
    }
}
?>