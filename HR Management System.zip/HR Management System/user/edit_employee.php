<?php
include('security.php');
include('db.php');

if (isset($_POST['edit_btn'])) {
    $id = $_POST['edit_id'];
    $query = "SELECT * FROM employees WHERE id='$id'";
    $query_run = mysqli_query($conn, $query);

    if (mysqli_num_rows($query_run) > 0) {
        $row = mysqli_fetch_assoc($query_run);
        ?>
        <form action="update_employee.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <label>Full Name</label>
            <input type="text" name="fullname" value="<?php echo $row['fullname']; ?>" required>
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $row['email']; ?>" required>
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo $row['phone']; ?>" required>
            <label>Position</label>
            <input type="text" name="position" value="<?php echo $row['position']; ?>" required>
            <label>Department</label>
            <input type="text" name="department" value="<?php echo $row['department']; ?>" required>
            <button type="submit" name="update_employee">Update</button>
        </form>
        <?php
    } else {
        echo "No record found";
    }
}
?>