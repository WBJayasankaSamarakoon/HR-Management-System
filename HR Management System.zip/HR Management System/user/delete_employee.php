<?php
include('db.php');

if (isset($_POST['delete_btn'])) {
    $id = mysqli_real_escape_string($conn, $_POST['delete_id']);

    // Delete employee from the database
    $query = "DELETE FROM employees WHERE id='$id'";
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $_SESSION['success'] = "Employee Deleted Successfully";
        header('Location: employee_management.php');
    } else {
        $_SESSION['status'] = "Employee Deletion Failed";
        header('Location: employee_management.php');
    }
}
?>