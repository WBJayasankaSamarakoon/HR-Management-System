<?php
include('db.php');

if (isset($_POST['update_employee'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $position = mysqli_real_escape_string($conn, $_POST['position']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);

    // Update employee in the database
    $query = "UPDATE employees SET fullname='$fullname', email='$email', phone='$phone', position='$position', department='$department' WHERE id='$id'";
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $_SESSION['success'] = "Employee Updated Successfully";
        header('Location: employee_management.php');
    } else {
        $_SESSION['status'] = "Employee Update Failed";
        header('Location: employee_management.php');
    }
}
?>