<?php
if (isset($_SESSION['success'])) {
    echo '<h2>' . $_SESSION['success'] . '</h2>';
    unset($_SESSION['success']);
}
if (isset($_SESSION['status'])) {
    echo '<h2>' . $_SESSION['status'] . '</h2>';
    unset($_SESSION['status']);
}
?>