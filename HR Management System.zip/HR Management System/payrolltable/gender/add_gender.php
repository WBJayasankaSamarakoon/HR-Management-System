<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ueshrdb";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve and escape form data
    $name = $conn->real_escape_string($_POST['name']);

    // Find the lowest available ID
    $result = $conn->query("SELECT MIN(t1.Id + 1) AS next_id FROM Gender t1 LEFT JOIN Gender t2 ON t1.Id + 1 = t2.Id WHERE t2.Id IS NULL");
    $row = $result->fetch_assoc();
    $new_id = $row['next_id'] ? $row['next_id'] : 1;

    // Insert data into the database
    $sql = "INSERT INTO Gender (Id, Name) VALUES ('$new_id', '$name')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Gender added successfully!'); window.location.href='view_gender.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Gender</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .form-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .form-container h1 {
            margin-top: 0;
        }
        .form-row {
            margin-bottom: 15px;
        }
        .form-row label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .form-row input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .form-row button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .form-row button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Add New Gender</h1>
        <form action="add_gender.php" method="post">
            <div class="form-row">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-row">
                <button type="submit">Add Gender</button>
            </div>
        </form>
    </div>
</body>
</html>
