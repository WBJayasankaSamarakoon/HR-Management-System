<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve gender ID from query string
$id = $conn->real_escape_string($_GET['id']);

// Delete gender from database
$sql = "DELETE FROM Gender WHERE Id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Gender deleted successfully!'); window.location.href='view_gender.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
