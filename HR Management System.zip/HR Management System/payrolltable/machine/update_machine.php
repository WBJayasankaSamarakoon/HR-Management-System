<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ueshrdb";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve and escape form data
    $id = $conn->real_escape_string($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $model = $conn->real_escape_string($_POST['model']);
    $brand = $conn->real_escape_string($_POST['brand']);

    // Update data in the database
    $sql = "UPDATE Machine SET Name='$name', Model='$model', Brand='$brand' WHERE Id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Machine updated successfully!'); window.location.href='view_machine.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Machine</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .popup {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            visibility: hidden;
        }
        .popup.active {
            visibility: visible;
        }
        .popup-content {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            width: 500px;
            max-width: 90%;
        }
        .popup-content h2 {
            margin-top: 0;
        }
        .popup-content .form-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .popup-content label {
            display: block;
            font-size: 12px;
        }
        .popup-content input[type="text"] {
            width: 100%;
            padding: 5px;
            margin-top: 3px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 12px;
        }
        .popup-content button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
            font-size: 14px;
        }
        .popup-content button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <button onclick="showPopup()">Update Machine</button>

    <div class="popup" id="popup">
        <div class="popup-content">
            <h2>Update Machine</h2>
            <?php
            if (isset($_GET['id'])) {
                // Database connection details
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "ueshrdb";

                // Create a connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check the connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Retrieve the machine details
                $id = $conn->real_escape_string($_GET['id']);
                $sql = "SELECT * FROM Machine WHERE Id='$id'";
                $result = $conn->query($sql);
                $machine = $result->fetch_assoc();

                $conn->close();
            }
            ?>

            <form action="update_machine.php" method="post">
                <input type="hidden" id="id" name="id" value="<?php echo isset($machine['Id']) ? $machine['Id'] : ''; ?>">
                <div class="form-row">
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo isset($machine['Name']) ? $machine['Name'] : ''; ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="model">Model:</label>
                        <input type="text" id="model" name="model" value="<?php echo isset($machine['Model']) ? $machine['Model'] : ''; ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label for="brand">Brand:</label>
                        <input type="text" id="brand" name="brand" value="<?php echo isset($machine['Brand']) ? $machine['Brand'] : ''; ?>" required>
                    </div>
                </div>
                <button type="submit">Update Machine</button>
            </form>
        </div>
    </div>

    <script>
        function showPopup() {
            document.getElementById('popup').classList.add('active');
        }
    </script>
</body>
</html>
