<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'id' is set in the GET request
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $machineId = $conn->real_escape_string($_GET['id']);

    // Fetch the machine details
    $sql = "SELECT * FROM Machine WHERE Id='$machineId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $machine = $result->fetch_assoc();
    } else {
        die("Machine not found.");
    }
} else {
    die("Invalid request.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $model = $conn->real_escape_string($_POST['model']);
    $brand = $conn->real_escape_string($_POST['brand']);

    // Update the machine record
    $sql = "UPDATE Machine SET Name='$name', Model='$model', Brand='$brand' WHERE Id='$machineId'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Machine updated successfully!'); window.location.href='view_machine.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Machine</title>
</head>

<body>
    <div class="form-container">
        <h1>Edit Machine</h1>
        <form action="edit_machine.php?id=<?php echo htmlspecialchars($machineId); ?>" method="post">
            <div class="form-row">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($machine['Name']); ?>"
                    required>
            </div>
            <div class="form-row">
                <label for="model">Model:</label>
                <input type="text" id="model" name="model" value="<?php echo htmlspecialchars($machine['Model']); ?>"
                    required>
            </div>
            <div class="form-row">
                <label for="brand">Brand:</label>
                <input type="text" id="brand" name="brand" value="<?php echo htmlspecialchars($machine['Brand']); ?>"
                    required>
            </div>
            <div class="form-row">
                <button type="submit">Update Machine</button>
            </div>
        </form>
    </div>
</body>

</html>