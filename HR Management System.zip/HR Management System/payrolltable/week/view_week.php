<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all weeks from the database
$sql = "SELECT * FROM Week";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Weeks</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
            padding: 0;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .action-buttons {
            text-align: left;
            margin-bottom: 20px;
        }

        .action-buttons a {
            text-decoration: none;
        }

        .action-buttons button {
            padding: 10px 15px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .action-buttons button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
            margin: 0 auto;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #f2f2f2;
        }

        td a button {
            padding: 5px 10px;
            font-size: 12px;
            margin-right: 5px;
        }

        .edit-btn {
            background-color: #28a745;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .edit-btn:hover {
            background-color: #218838;
        }

        .delete-btn {
            background-color: #dc3545;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        /* Styling for the Actions column */
        .actions-col {
            width: 150px;
            text-align: center;
        }
    </style>
</head>

<body>

    <h1>View Weeks</h1>

    <div class="action-buttons">
        <a href="add_week.php"><button>Add New Week</button></a>
    </div>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th class="actions-col">Actions</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo isset($row['Id']) ? htmlspecialchars($row['Id']) : ''; ?></td>
                    <td><?php echo isset($row['Name']) ? htmlspecialchars($row['Name']) : ''; ?></td>
                    <td class="actions-col">
                        <a href="edit_week.php?id=<?php echo isset($row['Id']) ? $row['Id'] : ''; ?>"><button
                                class="edit-btn">Edit</button></a>
                        <a href="delete_week.php?id=<?php echo isset($row['Id']) ? $row['Id'] : ''; ?>"
                            onclick="return confirm('Are you sure you want to delete this week?');"><button
                                class="delete-btn">Delete</button></a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">No weeks found.</td>
            </tr>
        <?php endif; ?>
    </table>

</body>

</html>

<?php
$conn->close();
?>