<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve position ID from query string
$id = $conn->real_escape_string($_GET['id']);

// Delete position from database
$sql = "DELETE FROM Position WHERE Id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Position deleted successfully!'); window.location.href='view_position.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
