<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ueshrdb";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'id' is set in the GET request
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $shiftId = $conn->real_escape_string($_GET['id']);

    // Fetch the shift details
    $sql = "SELECT * FROM Shift WHERE Id='$shiftId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $shift = $result->fetch_assoc();
    } else {
        die("Shift not found.");
    }
} else {
    die("Invalid request.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $startTime = $conn->real_escape_string($_POST['start_time']);
    $endTime = $conn->real_escape_string($_POST['end_time']);
    $week = $conn->real_escape_string($_POST['week']);

    // Update the shift record
    $sql = "UPDATE Shift SET StartTime='$startTime', EndTime='$endTime', Week='$week' WHERE Id='$shiftId'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Shift updated successfully!'); window.location.href='view_shift.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Shift</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .form-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .form-container h1 {
            margin-top: 0;
        }
        .form-row {
            margin-bottom: 15px;
        }
        .form-row label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .form-row input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .form-row button {
            padding: 10px 20px;
            background-color: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .form-row button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Edit Shift</h1>
        <form action="edit_shift.php?id=<?php echo htmlspecialchars($shiftId); ?>" method="post">
            <div class="form-row">
                <label for="start_time">Start Time:</label>
                <input type="time" id="start_time" name="start_time" value="<?php echo htmlspecialchars($shift['StartTime']); ?>" required>
            </div>
            <div class="form-row">
                <label for="end_time">End Time:</label>
                <input type="time" id="end_time" name="end_time" value="<?php echo htmlspecialchars($shift['EndTime']); ?>" required>
            </div>
            <div class="form-row">
                <label for="week">Week:</label>
                <input type="text" id="week" name="week" value="<?php echo htmlspecialchars($shift['Week']); ?>" required>
            </div>
            <div class="form-row">
                <button type="submit">Update Shift</button>
            </div>
        </form>
    </div>
</body>
</html>
